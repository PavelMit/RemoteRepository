# Second seminar. Git branches

This seminar shows the main command which you should know to work with git branches

## Creating of branches

* *git branch* - is a command which showing all existing branches in your repository

* *git branch branch_name* - is a command which creating a new branch in your repository

* *git checkout branch_name* - is a command which takes you to the requested branch

## Merging of branches

* *git merge branch_name* - is a command which merging information from the *branch_name* branch into the current branch.

## Conflicts

When you are megring branches conflicts can emerge if different information exists on similar lines in both branches.  

## Other info

* *git branch -d branch_name* - is a command which deletes *branch_name* branch